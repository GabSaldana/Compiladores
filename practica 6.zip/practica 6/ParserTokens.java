public interface ParserTokens {
public final static short NUMBER=257;
public final static short PRINT=258;
public final static short VAR=259;
public final static short BLTIN=260;
public final static short INDEF=261;
public final static short REPEAT=262;
public final static short LINE=263;
public final static short RIGHT=264;
public final static short CIRCULO=265;
public final static short COLOR=266;
public final static short OR=267;
public final static short AND=268;
public final static short GT=269;
public final static short LT=270;
public final static short GE=271;
public final static short LE=272;
public final static short EQ=273;
public final static short NOT=274;
}
