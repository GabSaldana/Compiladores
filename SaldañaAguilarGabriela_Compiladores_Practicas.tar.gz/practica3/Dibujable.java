import java.awt.*;

interface Dibujable {
	public void dibuja(Graphics g);
        public void moverFigura(Graphics g, double x1n, double y1n, double x2n, double y2n);
}
