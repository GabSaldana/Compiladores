package objetos3D;

/*
 * SeActivaAlAcercarse.java
 *
 * Created on 19 de febrero de 2004, 0:21
 */

/**
 *
 * @author  Administrador
 * @version 
 */
public interface SeActivaAlAcercarse {
    public void moverNavegador(float x, float z);
    public boolean reset();
}

