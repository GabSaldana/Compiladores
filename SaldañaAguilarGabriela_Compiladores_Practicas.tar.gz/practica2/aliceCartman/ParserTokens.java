public interface ParserTokens {
public final static short NUMBER=257;
public final static short PRINT=258;
public final static short FORWARD=259;
public final static short RIGHT=260;
}
